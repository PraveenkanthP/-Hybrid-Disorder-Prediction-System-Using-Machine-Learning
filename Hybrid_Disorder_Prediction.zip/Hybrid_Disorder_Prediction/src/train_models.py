from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.ensemble import GradientBoostingClassifier

def train_models(X_train, y_train):
    svm = SVC(probability=True, random_state=42)
    xgb = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
    gbm = GradientBoostingClassifier(random_state=42)

    svm.fit(X_train, y_train)
    xgb.fit(X_train, y_train)
    gbm.fit(X_train, y_train)

    return {'SVM': svm, 'XGBoost': xgb, 'GradientBoosting': gbm}